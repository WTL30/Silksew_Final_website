"use client"

import { useState, useEffect } from "react"
import { Clock } from "lucide-react"
import "../Offers/Offers.css"

const SaleCountdown = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  })

  useEffect(() => {
    const targetDate = new Date("Jan 27, 2025 00:00:00").getTime()

    const timer = setInterval(() => {
      const now = new Date().getTime()
      const difference = targetDate - now

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24))
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
        const seconds = Math.floor((difference % (1000 * 60)) / 1000)

        setTimeLeft({ days, hours, minutes, seconds })
      } else {
        clearInterval(timer)
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="sale-countdown">
      <div className="heading-container">
        <h1 className="offers-heading">Exclusive Offers for You</h1>
      </div>

      <div className="sale-container">
        <div className="left-section">
          <h2>Hurry up and Get 25% Discount!</h2>
          <div className="deals-section">
            <h3>Deals Of The Day</h3>
            <ul>
              <li>
                <span>🔥</span> Women Collection
              </li>
              <li>
                <span>🔥</span> Kid's Trends
              </li>
              <li>
                <span>🔥</span> Men Collection
              </li>
            </ul>
          </div>
        </div>

        <div className="right-section">
          <div className="sale-live-banner">
            <Clock className="clock-icon" />
            Sale is Live!
          </div>
          <div className="countdown-timer">
            {Object.entries(timeLeft).map(([unit, value]) => (
              <div key={unit} className="timer-box">
                <div className="timer-value">{value.toString().padStart(2, "0")}</div>
                <div className="timer-unit">{unit.charAt(0).toUpperCase() + unit.slice(1)}</div>
              </div>
            ))}
          </div>
          <button className="shop-now-btn">Shop Now</button>
        </div>
      </div>
    </div>
  )
}

export default SaleCountdown

